document.addEventListener(
  'DOMContentLoaded',
  function() {
    if (typeof(base2) != 'undefined') {    
      alert('Base2 is working!');
    }    
  }, false
);