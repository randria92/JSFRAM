document.addEventListener(
  'DOMContentLoaded',
  function() {
    var $foods = ['fruits', 'vegetables', 'meats', 'cheeses'];
    
    var $span  = document.querySelector('span');
    
    var $key   = $foods.indexOf('cheeses');

    if ($span.innerText) {
      $span.innerText = $key;
    } else {
      $span.textContent = $key;
    }
  }, false
);