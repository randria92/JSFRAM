document.addEventListener(
  'DOMContentLoaded',
  function() {
    var $nodes = document.querySelectorAll('li');

    $nodes.forEach(
      function($node) {
        $node.addEventListener(
          'mouseover',
           function() {
            this.classList.add('tmpOver');
          }, false
        );

        $node.addEventListener(
          'mouseout',
          function() {
            this.classList.remove('tmpOver');
          }, false
        );
        
        $node.addEventListener(
          'click',
          function() {
            this.classList.toggle('tmpOn');
          }, false
        );
      }
    );
  }, false
);