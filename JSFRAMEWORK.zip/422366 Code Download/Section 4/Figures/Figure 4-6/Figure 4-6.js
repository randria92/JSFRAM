document.addEventListener(
  'DOMContentLoaded',
  function() {
    var $nodes = document.getElementsByTagName('li');

    for (var $i = 0; $i < $nodes.length; $i++) {
      if ($nodes[$i].id == 'tmpCheeses') {
        $nodes[$i].className = 'tmpCheesesSelected';
      }
    }
  }, false
);