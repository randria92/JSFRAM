document.addEventListener(
  'DOMContentLoaded',
  function() {
    var $nodes = document.querySelectorAll('li');

    $nodes.forEach(
      function($node) {
        if ($node.id == 'tmpCheeses') {
          $node.className = 'tmpCheesesSelected';
        }
      }
    );
  }, false
);