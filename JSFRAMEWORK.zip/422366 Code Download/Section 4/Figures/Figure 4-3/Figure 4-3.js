document.addEventListener(
  'DOMContentLoaded',
  function() {
    var $foods = ['cheeses', 'fruits', 'vegetables', 'meats', 'cheeses'];

    document.querySelector('span#tmpIndexOf').innerHTML = 
      $foods.indexOf('cheeses');

    document.querySelector('span#tmpLastIndexOf').innerHTML = 
      $foods.lastIndexOf('cheeses');
  }, false
);