document.addEventListener(
  'DOMContentLoaded',
  function() {
    var setTextValue = function($obj, $value) {
      if ($obj.innerText) {
        $obj.innerText = $value;
      } else {
        $obj.textContent = $value;
      }
    };

    var $fruits     = ['apples', 'oranges', 'bananas'];
    var $vegetables = ['peppers', 'onions', 'tomatoes', 'peppers'];

    setTextValue(
      document.querySelector('li#tmpIndexOf-hasValue span'),
      $fruits.indexOf('bananas')
    );
    setTextValue(
      document.querySelector('li#tmpIndexOf-duplicateValues span'),
      $vegetables.indexOf('peppers')
    );
    setTextValue(
      document.querySelector('li#tmpIndexOf-noValue span'),
      $fruits.indexOf('cherries')
    );

    setTextValue(
      document.querySelector('li#tmpLastIndexOf-hasValue span'),
      $fruits.lastIndexOf('bananas')
    );
    setTextValue(
      document.querySelector('li#tmpLastIndexOf-duplicateValues span'),
      $vegetables.lastIndexOf('peppers')
    );
    setTextValue(
      document.querySelector('li#tmpLastIndexOf-noValue span'),
      $vegetables.lastIndexOf('squash')
    );
  }, false
);