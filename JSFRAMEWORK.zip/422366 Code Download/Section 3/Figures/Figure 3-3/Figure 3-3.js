document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.querySelectorAll('div.tmpName input').forEach(
      function($node) {

        $node.title = $node.value;

        $node.addEventListener(
          'focus',
          function() {
            if (this.value == this.title) {
              this.value = '';
            }
          }, false
        );

        $node.addEventListener(
          'blur',
          function() {
            if (!this.value) {
              this.value = this.title;
            }
          }, false
        );

      }
    );
  }, false
);