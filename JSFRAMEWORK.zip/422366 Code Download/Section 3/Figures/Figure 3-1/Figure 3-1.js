document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.querySelector('#tmpSearch').addEventListener(
      'focus',
      function() {
        if (this.value == 'Search') {
          this.value = '';
        }
      }, false
    );

    document.querySelector('#tmpSearch').addEventListener(
      'blur',
      function() {
        if (!this.value) {
          this.value = 'Search';
        }
      }, false
    );
  }, false
);