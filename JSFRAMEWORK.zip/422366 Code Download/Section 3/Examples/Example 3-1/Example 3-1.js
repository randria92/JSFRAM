document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.querySelector('span.code').addEventListener(
      'click',
      function() {
        window.open(
          'http://www.google.com/search?q=' + 
            encodeURIComponent(this.innerHTML),
          'googleSearch',
          ''
        );
      }, false
    );
  }, false
);