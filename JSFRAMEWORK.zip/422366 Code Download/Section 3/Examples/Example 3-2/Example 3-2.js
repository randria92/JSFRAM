document.addEventListener(
  'DOMContentLoaded',
  function() {

    document.querySelectorAll('tbody tr').forEach(
      function($node) {

        $node.addEventListener(
          'mouseover',
          function() {
            this.className = 'tmpRowMouseover';
          }, false
        );

        $node.addEventListener(
          'mouseout',
          function() {
            this.className = '';
          }, false
        );  

      }
    );

  }, false
);